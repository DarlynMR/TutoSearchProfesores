package com.rd.dmmr.tutosearchprofesores;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AgregarTutoriaDoc extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_tutoria_doc);
    }
}
